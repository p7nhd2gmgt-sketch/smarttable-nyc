$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidPath = Join-Path $projectRoot ".autosave.pid"

if (-not (Test-Path $pidPath)) {
  Write-Output "No autosave process file found."
  exit 0
}

$pidLine = Get-Content -LiteralPath $pidPath | Where-Object { $_ -like "pid=*" } | Select-Object -First 1
$autosavePid = [int]($pidLine -replace "^pid=", "")

if (Get-Process -Id $autosavePid -ErrorAction SilentlyContinue) {
  Stop-Process -Id $autosavePid -Force
  Remove-Item -LiteralPath $pidPath -Force
  Write-Output "Stopped autosave process $autosavePid."
} else {
  Remove-Item -LiteralPath $pidPath -Force
  Write-Output "Autosave process was not running."
}
