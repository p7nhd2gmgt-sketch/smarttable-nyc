param(
  [int]$IntervalSeconds = 60
)

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidPath = Join-Path $projectRoot ".autosave.pid"
$logPath = Join-Path $projectRoot "autosave.log"
$saveScript = Join-Path $projectRoot "save-project.ps1"

function Write-AutosaveLog {
  param([string]$Message)
  "$((Get-Date).ToString("s")) $Message" | Add-Content -LiteralPath $logPath -Encoding UTF8
}

function Get-ProjectSignature {
  $rows = Get-ChildItem -LiteralPath $projectRoot -Recurse -File -Force |
    Where-Object {
      $_.FullName -notlike (Join-Path $projectRoot "backups\*") -and
      $_.Name -notin @(".autosave.pid", "autosave.log")
    } |
    Sort-Object FullName |
    ForEach-Object {
      $relative = $_.FullName.Substring($projectRoot.Length).TrimStart("\")
      $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
      "$relative|$($_.Length)|$hash"
    }

  return ($rows -join "`n")
}

@(
  "pid=$PID"
  "startedAt=$((Get-Date).ToString("s"))"
  "intervalSeconds=$IntervalSeconds"
) | Set-Content -LiteralPath $pidPath -Encoding UTF8

Write-AutosaveLog "started pid=$PID intervalSeconds=$IntervalSeconds"

$lastSignature = Get-ProjectSignature

while ($true) {
  Start-Sleep -Seconds $IntervalSeconds
  $currentSignature = Get-ProjectSignature
  if ($currentSignature -ne $lastSignature) {
    $archivePath = & $saveScript -Reason "autosave"
    Write-AutosaveLog "saved archive=$archivePath"
    $lastSignature = Get-ProjectSignature
  }
}
