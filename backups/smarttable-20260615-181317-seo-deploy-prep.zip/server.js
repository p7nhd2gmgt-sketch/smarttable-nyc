import http from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, "public");
const port = Number(process.env.PORT || 4173);
const publicBaseUrl = (process.env.PUBLIC_BASE_URL || "").replace(/\/$/, "");

const restaurants = [
  {
    id: "hudson-hearth",
    name: "Hudson Hearth",
    district: "West Village",
    address: "128 Perry St, New York, NY 10014",
    cuisine: "New American",
    discount: 25,
    email: "reservations@hudsonhearth.example",
    rating: 4.8,
    seatsLeft: 12,
    tags: ["patio", "wine list", "dinner"],
    slots: ["17:30", "18:00", "20:30", "21:00"],
    description: "A polished neighborhood bistro with stronger deals for early and late dinner windows."
  },
  {
    id: "casa-luna",
    name: "Casa Luna Trattoria",
    district: "Nolita",
    address: "242 Mott St, New York, NY 10012",
    cuisine: "Italian",
    discount: 30,
    email: "manager@casaluna.example",
    rating: 4.7,
    seatsLeft: 8,
    tags: ["fresh pasta", "family-style", "fast reply"],
    slots: ["16:45", "17:15", "19:45", "20:15"],
    description: "Warm trattoria energy, handmade pasta, and discounted tables between peak turns."
  },
  {
    id: "greenline-kitchen",
    name: "Greenline Kitchen",
    district: "Williamsburg",
    address: "77 N 6th St, Brooklyn, NY 11249",
    cuisine: "Vegetarian",
    discount: 20,
    email: "hello@greenline.example",
    rating: 4.9,
    seatsLeft: 10,
    tags: ["vegan options", "lunch", "sustainable"],
    slots: ["12:00", "12:30", "13:00", "18:30"],
    description: "Seasonal plant-forward plates for quick lunches and relaxed dinners near the East River."
  },
  {
    id: "midtown-ember",
    name: "Midtown Ember Grill",
    district: "Midtown",
    address: "38 W 46th St, New York, NY 10036",
    cuisine: "Steak and grill",
    discount: 18,
    email: "host@midtownember.example",
    rating: 4.6,
    seatsLeft: 6,
    tags: ["grill", "business dinner", "bar"],
    slots: ["18:15", "18:45", "21:15"],
    description: "Charcoal grill, tight service, and quieter post-theater tables with limited discounts."
  }
];

const bookings = [];
const outbox = [];

const senders = {
  app: process.env.EMAIL_FROM || "Smarttable.com <no-reply@smarttable.com>"
};

function json(res, statusCode, payload) {
  res.writeHead(statusCode, {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store"
  });
  res.end(JSON.stringify(payload));
}

async function parseJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function clean(value) {
  return String(value ?? "").trim();
}

function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function findRestaurant(id) {
  return restaurants.find((restaurant) => restaurant.id === id);
}

function createBooking(payload) {
  const restaurant = findRestaurant(clean(payload.restaurantId));
  if (!restaurant) {
    return { error: "The selected restaurant could not be found." };
  }

  const guest = {
    name: clean(payload.guest?.name),
    email: clean(payload.guest?.email).toLowerCase(),
    phone: clean(payload.guest?.phone)
  };
  const date = clean(payload.date);
  const time = clean(payload.time);
  const partySize = Number(payload.partySize);

  if (!guest.name || !validateEmail(guest.email) || !guest.phone) {
    return { error: "Guest name, email, and phone number are required." };
  }
  if (!date || !restaurant.slots.includes(time)) {
    return { error: "Choose a valid date and time." };
  }
  if (!Number.isInteger(partySize) || partySize < 1 || partySize > 12) {
    return { error: "Party size must be between 1 and 12 guests." };
  }

  const booking = {
    id: crypto.randomUUID(),
    reference: `ST-${crypto.randomInt(10000, 99999)}`,
    status: "pending",
    restaurantId: restaurant.id,
    restaurantName: restaurant.name,
    restaurantEmail: restaurant.email,
    discount: restaurant.discount,
    date,
    time,
    partySize,
    notes: clean(payload.notes),
    guest,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  bookings.unshift(booking);
  restaurant.seatsLeft = Math.max(0, restaurant.seatsLeft - partySize);
  return { booking, restaurant };
}

function bookingSummary(booking) {
  const guestLabel = booking.partySize === 1 ? "guest" : "guests";
  return `${booking.restaurantName}, ${booking.date} at ${booking.time}, ${booking.partySize} ${guestLabel}, ${booking.discount}% off`;
}

async function deliverEmail(message) {
  const email = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    from: senders.app,
    ...message
  };

  if (process.env.RESEND_API_KEY) {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "content-type": "application/json"
      },
      body: JSON.stringify({
        from: email.from,
        to: [email.to],
        subject: email.subject,
        html: email.html,
        text: email.text
      })
    });

    if (!response.ok) {
      const detail = await response.text();
      throw new Error(`Email delivery failed: ${response.status} ${detail}`);
    }

    email.delivery = "sent";
  } else {
    email.delivery = "demo-outbox";
  }

  outbox.unshift(email);
  return email;
}

function guestRequestEmail(booking) {
  return {
    to: booking.guest.email,
    subject: `Reservation request received: ${booking.reference}`,
    text: `Hi ${booking.guest.name}! We received your reservation request: ${bookingSummary(booking)}. The restaurant will confirm the reservation by email.`,
    html: `
      <h2>Reservation request received</h2>
      <p>Hi ${booking.guest.name}!</p>
      <p>We received your reservation request.</p>
      <ul>
        <li><strong>Reference:</strong> ${booking.reference}</li>
        <li><strong>Reservation:</strong> ${bookingSummary(booking)}</li>
      </ul>
      <p>The restaurant will confirm the reservation by email.</p>
    `
  };
}

function restaurantRequestEmail(booking, req) {
  const baseUrl = publicBaseUrl || `http://${req.headers.host}`;
  return {
    to: booking.restaurantEmail,
    subject: `New discounted reservation: ${booking.reference}`,
    text: `A new reservation request arrived: ${bookingSummary(booking)}. Guest: ${booking.guest.name}, ${booking.guest.email}, ${booking.guest.phone}. Confirm it here: ${baseUrl}/api/bookings/${booking.id}/confirm`,
    html: `
      <h2>New reservation request</h2>
      <p><strong>${bookingSummary(booking)}</strong></p>
      <p>Guest: ${booking.guest.name}<br>Email: ${booking.guest.email}<br>Phone: ${booking.guest.phone}</p>
      <p>Notes: ${booking.notes || "none"}</p>
      <p><a href="${baseUrl}/api/bookings/${booking.id}/confirm">Confirm reservation</a></p>
    `
  };
}

function guestConfirmationEmail(booking) {
  return {
    to: booking.guest.email,
    subject: `Confirmed reservation: ${booking.reference}`,
    text: `Hi ${booking.guest.name}! The restaurant confirmed your reservation: ${bookingSummary(booking)}. Enjoy your meal.`,
    html: `
      <h2>Reservation confirmed</h2>
      <p>Hi ${booking.guest.name}!</p>
      <p>The restaurant confirmed your reservation.</p>
      <p><strong>${bookingSummary(booking)}</strong></p>
      <p>Reservation reference: ${booking.reference}</p>
    `
  };
}

function restaurantConfirmationCopy(booking) {
  return {
    to: booking.restaurantEmail,
    subject: `Confirmation recorded: ${booking.reference}`,
    text: `The reservation is confirmed: ${bookingSummary(booking)}. Guest: ${booking.guest.name}.`,
    html: `
      <h2>Confirmation recorded</h2>
      <p>The reservation has been confirmed and the guest has been notified.</p>
      <p><strong>${bookingSummary(booking)}</strong></p>
    `
  };
}

async function handleApi(req, res, pathname) {
  if (req.method === "GET" && pathname === "/api/restaurants") {
    return json(res, 200, { restaurants });
  }

  if (req.method === "GET" && pathname === "/api/bookings") {
    return json(res, 200, { bookings, outbox });
  }

  if (req.method === "GET" && pathname === "/api/outbox") {
    return json(res, 200, { outbox });
  }

  if (req.method === "POST" && pathname === "/api/bookings") {
    const payload = await parseJson(req);
    const result = createBooking(payload);
    if (result.error) return json(res, 400, { error: result.error });

    const { booking } = result;
    const emails = await Promise.all([
      deliverEmail(guestRequestEmail(booking)),
      deliverEmail(restaurantRequestEmail(booking, req))
    ]);

    return json(res, 201, { booking, emails });
  }

  const confirmMatch = pathname.match(/^\/api\/bookings\/([^/]+)\/confirm$/);
  if (confirmMatch && (req.method === "POST" || req.method === "GET")) {
    const booking = bookings.find((item) => item.id === confirmMatch[1]);
    if (!booking) return json(res, 404, { error: "Reservation not found." });
    booking.status = "confirmed";
    booking.updatedAt = new Date().toISOString();

    const emails = await Promise.all([
      deliverEmail(guestConfirmationEmail(booking)),
      deliverEmail(restaurantConfirmationCopy(booking))
    ]);

    if (req.method === "GET") {
      res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
      res.end(`
        <!doctype html>
        <meta charset="utf-8">
        <title>Reservation confirmed</title>
        <style>body{font-family:Arial,sans-serif;margin:48px;line-height:1.5;color:#16201c}a{color:#0b6b57}</style>
        <h1>Reservation confirmed</h1>
        <p>${booking.reference} - ${bookingSummary(booking)}</p>
        <p>The guest has been notified by email.</p>
        <p><a href="/">Back to booking dashboard</a></p>
      `);
      return;
    }

    return json(res, 200, { booking, emails });
  }

  const rejectMatch = pathname.match(/^\/api\/bookings\/([^/]+)\/reject$/);
  if (rejectMatch && req.method === "POST") {
    const booking = bookings.find((item) => item.id === rejectMatch[1]);
    if (!booking) return json(res, 404, { error: "Reservation not found." });
    booking.status = "rejected";
    booking.updatedAt = new Date().toISOString();
    const email = await deliverEmail({
      to: booking.guest.email,
      subject: `Reservation declined: ${booking.reference}`,
      text: `Hi ${booking.guest.name}. Unfortunately, the restaurant could not confirm your reservation: ${bookingSummary(booking)}.`,
      html: `<h2>Reservation declined</h2><p>Hi ${booking.guest.name}.</p><p>Unfortunately, the restaurant could not confirm your reservation.</p><p>${bookingSummary(booking)}</p>`
    });
    return json(res, 200, { booking, email });
  }

  return json(res, 404, { error: "Unknown API endpoint." });
}

async function serveStatic(req, res, pathname) {
  const filePath = pathname === "/" ? "/index.html" : pathname;
  const resolved = path.normalize(path.join(publicDir, filePath));

  if (!resolved.startsWith(publicDir)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  try {
    const content = await readFile(resolved);
    const ext = path.extname(resolved).toLowerCase();
    const contentTypes = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "text/javascript; charset=utf-8",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".webp": "image/webp",
      ".txt": "text/plain; charset=utf-8",
      ".xml": "application/xml; charset=utf-8",
      ".webmanifest": "application/manifest+json; charset=utf-8"
    };
    const dynamicAsset = [".html", ".css", ".js"].includes(ext);
    res.writeHead(200, {
      "content-type": contentTypes[ext] || "application/octet-stream",
      "cache-control": dynamicAsset ? "no-store" : "public, max-age=3600"
    });
    res.end(content);
  } catch {
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("Not found");
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url.pathname);
    } else {
      await serveStatic(req, res, url.pathname);
    }
  } catch (error) {
    json(res, 500, { error: error.message || "Server error." });
  }
});

server.listen(port, () => {
  console.log(`Smarttable.com running at http://localhost:${port}`);
  if (!process.env.RESEND_API_KEY) {
    console.log("Demo email mode: messages are stored in the in-app outbox.");
  }
});
