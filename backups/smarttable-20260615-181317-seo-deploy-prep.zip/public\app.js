const state = {
  restaurants: [],
  selectedRestaurant: null,
  selectedSlot: "",
  bookings: [],
  outbox: [],
  guest: JSON.parse(localStorage.getItem("smarttable.guest") || "null")
};

localStorage.removeItem("kedvasztal.guest");
localStorage.removeItem("dealtable.guest");

const els = {
  restaurantGrid: document.querySelector("#restaurantGrid"),
  restaurantCount: document.querySelector("#restaurantCount"),
  selectedName: document.querySelector("#selectedName"),
  selectedDiscount: document.querySelector("#selectedDiscount"),
  selectedMeta: document.querySelector("#selectedMeta"),
  slotGrid: document.querySelector("#slotGrid"),
  bookingForm: document.querySelector("#bookingForm"),
  bookButton: document.querySelector("#bookButton"),
  dateInput: document.querySelector("#dateInput"),
  partyInput: document.querySelector("#partyInput"),
  notesInput: document.querySelector("#notesInput"),
  guestStrip: document.querySelector("#guestStrip"),
  accountButton: document.querySelector("#accountButton"),
  accountDialog: document.querySelector("#accountDialog"),
  accountForm: document.querySelector("#accountForm"),
  closeDialog: document.querySelector("#closeDialog"),
  searchInput: document.querySelector("#searchInput"),
  cuisineFilter: document.querySelector("#cuisineFilter"),
  discountFilter: document.querySelector("#discountFilter"),
  bookingList: document.querySelector("#bookingList"),
  outboxList: document.querySelector("#outboxList"),
  refreshButton: document.querySelector("#refreshButton"),
  toast: document.querySelector("#toast")
};

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  window.setTimeout(() => els.toast.classList.remove("show"), 3200);
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    headers: { "content-type": "application/json" },
    ...options
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Something went wrong.");
  return payload;
}

function saveGuest(guest) {
  state.guest = guest;
  localStorage.setItem("smarttable.guest", JSON.stringify(guest));
  renderGuest();
}

function renderGuest() {
  if (state.guest) {
    els.accountButton.textContent = state.guest.name;
    els.guestStrip.innerHTML = `
      <span>${state.guest.name} - ${state.guest.email}</span>
      <button type="button" class="link-button" id="changeGuest">Edit</button>
    `;
    document.querySelector("#changeGuest").addEventListener("click", openAccount);
  } else {
    els.accountButton.textContent = "Sign up";
    els.guestStrip.innerHTML = `
      <span>No guest profile yet</span>
      <button type="button" class="link-button" id="openRegisterFromForm">Sign up</button>
    `;
    document.querySelector("#openRegisterFromForm").addEventListener("click", openAccount);
  }
}

function openAccount() {
  if (state.guest) {
    els.accountForm.elements.name.value = state.guest.name;
    els.accountForm.elements.email.value = state.guest.email;
    els.accountForm.elements.phone.value = state.guest.phone;
  }
  els.accountDialog.showModal();
}

function restaurantMatchesFilters(restaurant) {
  const search = els.searchInput.value.trim().toLowerCase();
  const cuisine = els.cuisineFilter.value;
  const minDiscount = Number(els.discountFilter.value);
  const haystack = `${restaurant.name} ${restaurant.cuisine} ${restaurant.district} ${restaurant.tags.join(" ")}`.toLowerCase();

  return (!search || haystack.includes(search))
    && (!cuisine || restaurant.cuisine === cuisine)
    && restaurant.discount >= minDiscount;
}

function renderCuisineOptions() {
  const cuisines = [...new Set(state.restaurants.map((item) => item.cuisine))].sort();
  els.cuisineFilter.innerHTML = '<option value="">All</option>';
  for (const cuisine of cuisines) {
    const option = document.createElement("option");
    option.value = cuisine;
    option.textContent = cuisine;
    els.cuisineFilter.append(option);
  }
}

function renderRestaurants() {
  const filtered = state.restaurants.filter(restaurantMatchesFilters);
  const resultLabel = filtered.length === 1 ? "result" : "results";
  els.restaurantCount.textContent = `${filtered.length} ${resultLabel}`;

  if (!filtered.length) {
    els.restaurantGrid.innerHTML = '<div class="empty-state">No restaurants match these filters.</div>';
    return;
  }

  els.restaurantGrid.innerHTML = filtered.map((restaurant) => `
    <article class="restaurant-card">
      <div class="restaurant-photo" aria-hidden="true"></div>
      <div class="restaurant-body">
        <div class="restaurant-footer">
          <div>
            <h3>${restaurant.name}</h3>
            <div class="restaurant-meta">
              <span>${restaurant.district}</span><span class="dot"></span><span>${restaurant.cuisine}</span><span class="dot"></span><span>${restaurant.rating}/5</span>
            </div>
          </div>
          <strong class="discount-pill">-${restaurant.discount}%</strong>
        </div>
        <p class="muted">${restaurant.description}</p>
        <div class="tag-row">
          ${restaurant.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
        </div>
        <div class="restaurant-footer">
          <span class="muted">${restaurant.seatsLeft} discounted seats</span>
          <button class="ghost-button" type="button" data-select="${restaurant.id}">Select</button>
        </div>
      </div>
    </article>
  `).join("");

  document.querySelectorAll("[data-select]").forEach((button) => {
    button.addEventListener("click", () => selectRestaurant(button.dataset.select));
  });
}

function selectRestaurant(id) {
  state.selectedRestaurant = state.restaurants.find((restaurant) => restaurant.id === id);
  state.selectedSlot = state.selectedRestaurant?.slots[0] || "";
  renderSelectedRestaurant();
  document.querySelector(".booking-card").scrollIntoView({ behavior: "smooth", block: "center" });
}

function renderSelectedRestaurant() {
  const restaurant = state.selectedRestaurant;
  if (!restaurant) {
    els.selectedName.textContent = "Choose a restaurant";
    els.selectedDiscount.textContent = "-";
    els.selectedMeta.textContent = "Choose a restaurant from the list below.";
    els.slotGrid.innerHTML = "";
    return;
  }

  els.selectedName.textContent = restaurant.name;
  els.selectedDiscount.textContent = `-${restaurant.discount}%`;
  els.selectedMeta.textContent = `${restaurant.address} - ${restaurant.cuisine} - ${restaurant.seatsLeft} discounted seats available`;
  els.slotGrid.innerHTML = restaurant.slots.map((slot) => `
    <button class="slot-button ${slot === state.selectedSlot ? "active" : ""}" type="button" role="radio" aria-checked="${slot === state.selectedSlot}" data-slot="${slot}">
      ${slot}
    </button>
  `).join("");
  document.querySelectorAll("[data-slot]").forEach((button) => {
    button.addEventListener("click", () => {
      state.selectedSlot = button.dataset.slot;
      renderSelectedRestaurant();
    });
  });
}

function statusLabel(status) {
  return {
    pending: "Awaiting confirmation",
    confirmed: "Confirmed",
    rejected: "Declined"
  }[status] || status;
}

function renderBookings() {
  if (!state.bookings.length) {
    els.bookingList.innerHTML = '<div class="empty-state">No reservation requests yet.</div>';
    return;
  }

  els.bookingList.innerHTML = state.bookings.map((booking) => `
    <article class="booking-item">
      <div class="outbox-topline">
        <h3>${booking.reference}</h3>
        <span class="status ${booking.status}">${statusLabel(booking.status)}</span>
      </div>
      <p>${booking.restaurantName}<br>${booking.date} ${booking.time} - ${booking.partySize} ${booking.partySize === 1 ? "guest" : "guests"} - ${booking.discount}% off</p>
      <p>${booking.guest.name} - ${booking.guest.email}</p>
      ${booking.status === "pending" ? `
        <div class="booking-actions">
          <button class="primary-button" type="button" data-confirm="${booking.id}">Confirm</button>
          <button class="ghost-button" type="button" data-reject="${booking.id}">Decline</button>
        </div>
      ` : ""}
    </article>
  `).join("");

  document.querySelectorAll("[data-confirm]").forEach((button) => {
    button.addEventListener("click", () => updateBooking(button.dataset.confirm, "confirm"));
  });
  document.querySelectorAll("[data-reject]").forEach((button) => {
    button.addEventListener("click", () => updateBooking(button.dataset.reject, "reject"));
  });
}

function renderOutbox() {
  if (!state.outbox.length) {
    els.outboxList.innerHTML = '<div class="empty-state">Outgoing emails will appear here.</div>';
    return;
  }

  els.outboxList.innerHTML = state.outbox.slice(0, 8).map((email) => `
    <article class="outbox-item">
      <div class="outbox-topline">
        <h3>${email.subject}</h3>
        <span class="status confirmed">${email.delivery === "sent" ? "sent" : "demo"}</span>
      </div>
      <p>To: ${email.to}<br>${new Date(email.createdAt).toLocaleString("en-US", { timeZone: "America/New_York" })}</p>
    </article>
  `).join("");
}

async function refreshStatus() {
  const payload = await request("/api/bookings");
  state.bookings = payload.bookings;
  state.outbox = payload.outbox;
  renderBookings();
  renderOutbox();
}

async function updateBooking(id, action) {
  try {
    await request(`/api/bookings/${id}/${action}`, { method: "POST" });
    await refreshStatus();
    showToast(action === "confirm" ? "The confirmation email is ready." : "The decline email is ready.");
  } catch (error) {
    showToast(error.message);
  }
}

async function createBooking(event) {
  event.preventDefault();

  if (!state.guest) {
    openAccount();
    showToast("Create a guest profile before sending a reservation request.");
    return;
  }

  if (!state.selectedRestaurant) {
    showToast("Choose a restaurant before booking.");
    return;
  }

  try {
    els.bookButton.disabled = true;
    await request("/api/bookings", {
      method: "POST",
      body: JSON.stringify({
        restaurantId: state.selectedRestaurant.id,
        date: els.dateInput.value,
        time: state.selectedSlot,
        partySize: Number(els.partyInput.value),
        notes: els.notesInput.value,
        guest: state.guest
      })
    });
    els.notesInput.value = "";
    await loadInitialData();
    await refreshStatus();
    showToast("Reservation request sent. Emails went to the guest and the restaurant.");
  } catch (error) {
    showToast(error.message);
  } finally {
    els.bookButton.disabled = false;
  }
}

async function loadInitialData() {
  const payload = await request("/api/restaurants");
  state.restaurants = payload.restaurants;
  if (!state.selectedRestaurant && state.restaurants.length) {
    state.selectedRestaurant = state.restaurants[0];
    state.selectedSlot = state.selectedRestaurant.slots[0];
  } else if (state.selectedRestaurant) {
    state.selectedRestaurant = state.restaurants.find((restaurant) => restaurant.id === state.selectedRestaurant.id) || state.restaurants[0];
  }
  renderCuisineOptions();
  renderRestaurants();
  renderSelectedRestaurant();
}

function bindEvents() {
  els.accountButton.addEventListener("click", openAccount);
  els.closeDialog.addEventListener("click", () => els.accountDialog.close());
  els.accountForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const form = new FormData(els.accountForm);
    saveGuest({
      name: String(form.get("name")).trim(),
      email: String(form.get("email")).trim(),
      phone: String(form.get("phone")).trim()
    });
    els.accountDialog.close();
    showToast("Profile saved.");
  });
  els.bookingForm.addEventListener("submit", createBooking);
  els.searchInput.addEventListener("input", renderRestaurants);
  els.cuisineFilter.addEventListener("change", renderRestaurants);
  els.discountFilter.addEventListener("change", renderRestaurants);
  els.refreshButton.addEventListener("click", async () => {
    await loadInitialData();
    await refreshStatus();
    showToast("Refreshed.");
  });
}

async function boot() {
  els.dateInput.value = todayIso();
  els.dateInput.min = todayIso();
  bindEvents();
  renderGuest();
  await loadInitialData();
  await refreshStatus();
}

boot().catch((error) => showToast(error.message));
