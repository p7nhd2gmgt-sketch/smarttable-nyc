# Smarttable.com Deployment Checklist

## Already prepared in this project

- Canonical URL: `https://smarttable.com/`
- SEO description and social preview tags
- Structured data for `Organization`, `WebSite`, and `WebApplication`
- `robots.txt`
- `sitemap.xml`
- `PUBLIC_BASE_URL` support for production email confirmation links
- `.env.example` for hosting environment variables

## What still needs your accounts

1. Buy or connect the `smarttable.com` domain at a domain registrar.
2. Deploy this project to a Node-capable host.
3. Set environment variables on the host:

```text
PORT=4173
PUBLIC_BASE_URL=https://smarttable.com
EMAIL_FROM=Smarttable.com <reservations@smarttable.com>
RESEND_API_KEY=<your Resend key>
```

4. Point DNS to the host using the host-provided records.
5. Enable HTTPS on the host.
6. Add `https://smarttable.com` in Google Search Console.
7. Verify domain ownership with the DNS TXT record Google gives you.
8. Submit this sitemap in Search Console:

```text
https://smarttable.com/sitemap.xml
```

9. Use URL Inspection for:

```text
https://smarttable.com/
```

10. Request indexing after the live page loads correctly.

## Recommended production command

```powershell
node server.js
```
