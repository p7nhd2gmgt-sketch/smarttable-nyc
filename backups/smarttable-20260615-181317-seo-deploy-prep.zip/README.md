# Smarttable.com

A discounted New York restaurant reservation prototype with guest sign-up, restaurant selection, reservation requests, two-way email notifications, and restaurant confirmation.

## Start

```powershell
.\start.ps1
```

Default local URL:

```text
http://localhost:4173
```

Production domain target:

```text
https://smarttable.com
```

If Node.js is available on your PATH, this also works:

```powershell
npm start
```

## Email behavior

By default, the app runs in demo mode: every email appears in the "Outgoing notifications" panel. To send real emails, set a Resend API key and sender address:

```powershell
$env:RESEND_API_KEY="..."
$env:EMAIL_FROM="Smarttable.com <reservations@smarttable.com>"
$env:PUBLIC_BASE_URL="https://smarttable.com"
.\start.ps1
```

When a reservation request is created, emails are prepared for both the guest and the restaurant. The restaurant can confirm through the email link or the dashboard, and the guest receives the final confirmation email.

## Project backups

Create a manual snapshot:

```powershell
.\save-project.ps1
```

Run continuous autosave in the background:

```powershell
.\autosave-project.ps1
```

Stop autosave:

```powershell
.\stop-autosave.ps1
```

Backups are saved as timestamped zip files in `backups/`.
Manual saves are zip archives; autosave creates timestamped snapshot folders when files change.

## Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for the live-domain, DNS, hosting, and Google Search Console checklist.
